package com.changwonPP.domain;

public class Member {
	private String m_id;
	private String m_pw;
	private String m_name;
	private String m_birthday1;
	private String m_birthday2;
	private String m_birthday3;
	private String m_mail;
	private String m_phone1;
	private String m_phone2;
	private String m_phone3;
	private String m_sex;
	private int m_type;
	
	public Member() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getM_id() {
		return m_id;
	}

	public void setM_id(String m_id) {
		this.m_id = m_id;
	}

	public String getM_pw() {
		return m_pw;
	}

	public void setM_pw(String m_pw) {
		this.m_pw = m_pw;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public String getM_birthday1() {
		return m_birthday1;
	}

	public void setM_birthday1(String m_birthday1) {
		this.m_birthday1 = m_birthday1;
	}

	public String getM_birthday2() {
		return m_birthday2;
	}

	public void setM_birthday2(String m_birthday2) {
		this.m_birthday2 = m_birthday2;
	}

	public String getM_birthday3() {
		return m_birthday3;
	}

	public void setM_birthday3(String m_birthday3) {
		this.m_birthday3 = m_birthday3;
	}

	public String getM_mail() {
		return m_mail;
	}

	public void setM_mail(String m_mail) {
		this.m_mail = m_mail;
	}

	public String getM_phone1() {
		return m_phone1;
	}

	public void setM_phone1(String m_phone1) {
		this.m_phone1 = m_phone1;
	}

	public String getM_phone2() {
		return m_phone2;
	}

	public void setM_phone2(String m_phone2) {
		this.m_phone2 = m_phone2;
	}

	public String getM_phone3() {
		return m_phone3;
	}

	public void setM_phone3(String m_phone3) {
		this.m_phone3 = m_phone3;
	}

	public String getM_sex() {
		return m_sex;
	}

	public void setM_sex(String m_sex) {
		this.m_sex = m_sex;
	}

	public int getM_type() {
		return m_type;
	}

	public void setM_type(int m_type) {
		this.m_type = m_type;
	}
}
