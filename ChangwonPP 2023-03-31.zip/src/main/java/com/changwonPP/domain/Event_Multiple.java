package com.changwonPP.domain;

public class Event_Multiple {
   private int id;
   private String e_number;
   private String file_name;
   
   public Event_Multiple() {
      super();
      // TODO Auto-generated constructor stub
   }

   public int getId() {
      return id;
   }

   public void setId(int id) {
      this.id = id;
   }

   public String getE_number() {
      return e_number;
   }

   public void setE_number(String e_number) {
      this.e_number = e_number;
   }

   public String getFile_name() {
      return file_name;
   }

   public void setFile_name(String file_name) {
      this.file_name = file_name;
   }
   
   
}